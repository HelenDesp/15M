
import React, { useState } from "react";
import { useAccount, useBalance } from "wagmi";

export default function WalletInfoCard() {
  const { address, isConnected, chain } = useAccount();
  const { data: ethBalance } = useBalance({
    address,
    enabled: !!address,
  });
  const [copied, setCopied] = useState(false);

  if (!isConnected) return null;

  const formatAddress = (addr) => {
    return `${addr.substring(0, 6)}...${addr.substring(addr.length - 4)}`;
  };

  const explorer = `https://basescan.org/address/${address}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex items-center justify-between gap-4">
      <div>
        <h4 className="text-sm font-medium text-gray-500 dark:text-white">Wallet</h4>
        <p className="text-sm font-bold text-gray-700 dark:text-white">
          {formatAddress(address)}
        </p>
        <p className="text-xs text-gray-500 dark:text-gray-400">
          Base
        </p>
        <a href={explorer} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-500">
          View on BaseScan
        </a>
      </div>
      <button onClick={handleCopy} className="text-xs border rounded px-2 py-1">
        {copied ? "Copied!" : "Copy"}
      </button>
    </div>
  );
}
