import { useAccount } from "wagmi";
import { useEffect, useState } from "react";
import { formatUnits } from "viem";

export default function TokenBalances() {
  const { address } = useAccount();
  const [balance, setBalance] = useState(null);

  useEffect(() => {
    const getBalance = async () => {
      try {
        const res = await fetch(
          `https://api.basescan.org/api?module=account&action=balance&address=${address}`
        );
        const data = await res.json();
        if (data.result) {
          setBalance(formatUnits(BigInt(data.result), 18));
        }
      } catch (err) {
        console.error(err);
      }
    };
    if (address) getBalance();
  }, [address]);

  return (
    <div>
      <h3 className="font-medium text-gray-600 dark:text-white">Base ETH</h3>
      <p className="text-lg font-semibold text-gray-900 dark:text-white">
        {balance !== null ? `${balance} ETH` : "Loading..."}
      </p>
    </div>
  );
}
